package com.example.practica01.controladores;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;

public class ListadoController {

    @FXML private ComboBox<String> comboFiltroDepartamento;

    @FXML
    private void initialize() {
        configurarTabla();
        configurarCombobox();
    }

    private void configurarTabla() {
    }

    private void configurarCombobox() {
        comboFiltroDepartamento.getItems().addAll("Todos", "Ventas", "TI", "Recursos Humanos");
        comboFiltroDepartamento.setValue("Todos");
    }
}

