package com.example.practica01.controladores;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;

public class MantenimientoController {

    @FXML private ComboBox<String> comboDepartamento;
    @FXML private DatePicker selectorFecha;

    @FXML
    private void initialize() {
        configurarCombobox();
        selectorFecha.setValue(LocalDate.now());
    }

    private void configurarCombobox() {
        comboDepartamento.getItems().addAll("Ventas", "TI", "Recursos Humanos");
    }

    @FXML
    private void guardarRegistro() {
    }

    @FXML
    public void cancelar() {
    }
}

