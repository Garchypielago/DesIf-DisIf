module ExamenUnidades9_10_AGS {
    requires javafx.controls;
    requires javafx.fxml;
    opens ejercicio1_AGS to javafx.fxml;
    opens ejercicio2_AGS to javafx.fxml;
}
