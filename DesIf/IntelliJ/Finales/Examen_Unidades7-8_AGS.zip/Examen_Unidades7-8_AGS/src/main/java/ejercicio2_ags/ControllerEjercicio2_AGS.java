package ejercicio2_ags;

import javafx.fxml.FXML;
import javafx.scene.control.*;

public class ControllerEjercicio2_AGS {

    @FXML private TreeView<String> treeViewLeft;
    @FXML private ComboBox<String> comboDescripcion;
    @FXML private TableView<?> tableProductos;
    @FXML private Button btnOcultarColumnas;

    @FXML
    public void initialize() {
        // TODO: expandir nodos de treeViewLeft por defecto
        // TODO: hacer textos editables
        // TODO: comboDescripcion promptText "Seleccione un producto"
        // TODO: configurar TableView usando Producto.java
        // TODO: implementar ocultación de columnas
    }
}