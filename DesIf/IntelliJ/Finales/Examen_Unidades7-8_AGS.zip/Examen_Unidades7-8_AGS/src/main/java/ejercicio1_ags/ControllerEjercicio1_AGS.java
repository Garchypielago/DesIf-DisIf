package ejercicio1_ags;

import javafx.fxml.FXML;
import javafx.scene.control.*;

public class ControllerEjercicio1_AGS {

    @FXML private MenuItem menuItemAuto;
    @FXML private MenuItem menuItemManual;
    @FXML private Accordion accordion;
    @FXML private RadioButton rbAdmin;
    @FXML private RadioButton rbUsuario;
    @FXML private Spinner<Integer> spinnerExperiencia;
    @FXML private Button btnAceptar;
    @FXML private Button btnCancelar;
    @FXML private TextArea textArea;

    @FXML
    public void initialize() {
        // TODO: marcar menuItemAuto por defecto
        // TODO: deshabilitar menuItemManual
        // TODO: configurar spinner con paso 5 y editable
        // TODO: añadir manejadores
    }
}