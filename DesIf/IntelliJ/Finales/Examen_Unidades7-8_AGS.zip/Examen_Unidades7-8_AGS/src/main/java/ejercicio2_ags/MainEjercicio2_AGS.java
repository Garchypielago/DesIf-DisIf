package ejercicio2_ags;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainEjercicio2_AGS extends Application {

    public MainEjercicio2_AGS() {
        // TODO: inicialización previa
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("Ejercicio2_AGS.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setTitle("Ejercicio 2 – AGS");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}