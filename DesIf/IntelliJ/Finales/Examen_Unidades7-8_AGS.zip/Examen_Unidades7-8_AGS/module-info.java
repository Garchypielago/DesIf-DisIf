module ejercicio1_ags {
    requires javafx.controls;
    requires javafx.fxml;

    opens ejercicio1_ags to javafx.fxml;
}