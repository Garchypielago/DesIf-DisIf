package com.example.ej81.ej842;

import javafx.fxml.FXML;

public class Ej02Controller {

    @FXML
    private void initialize() {
        
    }
}