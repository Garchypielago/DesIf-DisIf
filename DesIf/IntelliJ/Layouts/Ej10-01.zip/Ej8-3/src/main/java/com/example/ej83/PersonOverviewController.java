package com.example.ej83;

import com.example.ej83.objects.DateUtil;
import com.example.ej83.objects.Person;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;

import java.io.IOException;
import java.util.Optional;

public class PersonOverviewController {
    @FXML
    private TableView<Person> personTable;
    @FXML
    private TableColumn<Person,String> firstNameColumn;
    @FXML
    private TableColumn<Person,String> secondNameColumn;

    @FXML
    private Label firstNameLabel;
    @FXML
    private Label secondNameLabel;
    @FXML
    private Label streetLabel;
    @FXML
    private Label cityLabel;
    @FXML
    private Label postalCodeLabel;
    @FXML
    private Label birthdayLabel;

    private Ej8_3Application application;

    @FXML
    private void initialize() {
        firstNameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        secondNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
        personTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showPersonDetails(newValue)
        );
        showPersonDetails(null);
    }

    private void showPersonDetails(Person person) {
        if (person != null) {
            firstNameLabel.setText(person.getFirstName());
            secondNameLabel.setText(person.getLastName());
            streetLabel.setText(person.getStreetAddress());
            cityLabel.setText(person.getCity());
            postalCodeLabel.setText(person.getPostalCode());
            birthdayLabel.setText(DateUtil.format(person.getBirthDate())); // Usa DateUtil para formatear
        } else {
            // Limpiar etiquetas si no hay selección
            firstNameLabel.setText("");
            secondNameLabel.setText("");
            streetLabel.setText("");
            cityLabel.setText("");
            postalCodeLabel.setText("");
            birthdayLabel.setText("");
        }
    }


    public void setApplication(Ej8_3Application application) {
        this.application = application;
        personTable.setItems(this.application.getPeopleData());
    }

    @FXML
    private void handleNewPerson() {
        Dialog<Person> dialog = new Dialog<>();
        dialog.setTitle("New Contact");
        dialog.initOwner(application.getPrimaryStage());

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("PersonEditDialog.fxml"));
            DialogPane dialogPane = loader.load();

            dialog.setDialogPane(dialogPane);
            PersonEditDialogController controller = loader.getController();
            controller.setDialog(dialog);

            Optional<Person> result = dialog.showAndWait();
            result.ifPresent(person -> application.getPeopleData().add(person));

        } catch (IOException e) {
            // Mostrar error detallado
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Failed to load dialog");
            alert.setContentText("Check the FXML file for syntax errors: " + e.getMessage());
            alert.showAndWait();
            e.printStackTrace();
        }
    }



}